package com.tielote.widget

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.actionStartActivity
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.currentState
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.layout.height
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.graphics.Color
import androidx.glance.unit.dp

object TieLotWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            val prefs = currentState<androidx.glance.state.Preferences>()
            val lot = prefs[TrackerKeys.LOT]
            val date = prefs[TrackerKeys.DATE] ?: "Todavía sin consultar"
            val checked = prefs[TrackerKeys.CHECKED] ?: "Añade el widget y abre la app"
            Column(
                modifier = GlanceModifier.fillMaxSize().background(ColorProvider(Color(0xFFF5F8FF))).padding(14.dp),
                verticalAlignment = Alignment.Vertical.Top,
                horizontalAlignment = Alignment.Horizontal.Start
            ) {
                Text("MI TIE · SAN FELIPE", style = TextStyle(color = ColorProvider(Color(0xFF183B78)), fontWeight = FontWeight.Bold))
                Spacer(GlanceModifier.height(5.dp))
                Text("Lote publicado: ${lot?.toString() ?: "—"}", style = TextStyle(color = ColorProvider(Color(0xFF172033)), fontWeight = FontWeight.Bold))
                Text("Tu lote: 297", style = TextStyle(color = ColorProvider(Color(0xFF172033))))
                Text(if (lot != null && lot >= 297) "Comprueba la recogida" else "Pendiente", style = TextStyle(color = ColorProvider(Color(0xFF2454A6))))
                Spacer(GlanceModifier.height(4.dp))
                Text("Fuente: Portal Extranjería · $date", style = TextStyle(color = ColorProvider(Color(0xFF505B6B))))
                Text("Consulta: $checked", style = TextStyle(color = ColorProvider(Color(0xFF505B6B))))
            }
        }
    }
}

class TieWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = TieLotWidget
}
