# Mi TIE · San Felipe (Android)

Widget Android para vigilar el lote publicado para la Comisaría de Extranjería de San Felipe, Madrid. Lote objetivo preconfigurado: `2026/297` (se compara el número `297`).

## Incluye
- Widget de pantalla de inicio con lote, fecha de publicación y hora de consulta.
- Consulta periódica aproximada cada 24 horas con WorkManager.
- Consulta manual desde la aplicación.
- Notificación cuando el lote publicado alcance o supere el objetivo.
- Si la web no responde o cambia su formato, se conserva el último dato válido; no se inventa un lote.

## Fuente
Portal Extranjería: https://portalextranjeria.com/lotes-nie-madrid/

Es una fuente privada, no un sistema oficial de la Policía Nacional. El lote alcanzado no confirma que la tarjeta esté físicamente disponible; verifica las instrucciones de recogida antes de desplazarte.

## Herramientas fijadas
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (en GitHub Actions)
- JDK: 17
- Kotlin: 2.0.21
- Kotlin Compose compiler plugin: 2.0.21
- compileSdk: 35
- Jetpack Glance: 1.1.1
- WorkManager: 2.10.0
- DataStore Preferences: 1.1.1
- Jsoup: 1.18.3

## Compilar
Sube el contenido de este ZIP directamente a la raíz del repositorio. Crea `.github/workflows/android.yml` y utiliza el workflow que se proporciona por separado. En GitHub abre **Actions**, ejecuta **Build Android APK** y descarga el artefacto.

## Limitaciones
- WorkManager no garantiza una ejecución a una hora exacta: Android puede aplazarla por batería o conectividad.
- La extracción depende de que la página conserve el texto y la estructura que reconoce el lector.
- El código debe validarse con una ejecución real de GitHub Actions; una revisión estática no sustituye una compilación.
- Requiere Android 8.0 (API 26) o posterior.
