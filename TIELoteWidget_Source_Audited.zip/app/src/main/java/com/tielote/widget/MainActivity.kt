package com.tielote.widget

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(40, 40, 40, 40)
            setBackgroundColor(android.graphics.Color.rgb(245, 248, 255))
        }
        root.addView(TextView(this).apply {
            text = "Mi TIE · San Felipe"
            textSize = 26f
            setTextColor(android.graphics.Color.rgb(24, 59, 120))
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Comisaría: San Felipe, Madrid\nTu lote: 2026/297\n\nLa app consultará la web una vez al día. Android puede retrasar la ejecución para ahorrar batería."
            textSize = 17f
            setTextColor(android.graphics.Color.rgb(35, 45, 65))
            setPadding(0, 24, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "Comprobar lote ahora"
            setOnClickListener {
                WorkManager.getInstance(this@MainActivity).enqueue(OneTimeWorkRequestBuilder<CheckLotWorker>().build())
            }
        })
        root.addView(TextView(this).apply {
            text = "Después, mantén pulsada la pantalla de inicio de tu móvil, entra en Widgets y añade ‘Mi TIE · San Felipe’."
            textSize = 15f
            setTextColor(android.graphics.Color.DKGRAY)
            setPadding(0, 24, 0, 0)
        })
        setContentView(root)
        scheduleDailyCheck()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun scheduleDailyCheck() {
        val daily = PeriodicWorkRequestBuilder<CheckLotWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("daily_tie_lot_check", ExistingPeriodicWorkPolicy.KEEP, daily)
        WorkManager.getInstance(this).enqueueUniqueWork("initial_tie_lot_check", androidx.work.ExistingWorkPolicy.KEEP, OneTimeWorkRequestBuilder<CheckLotWorker>().build())
    }
}
