package com.tielote.widget

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.glance.GlanceId
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.state.PreferencesGlanceStateDefinition
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object TrackerKeys {
    val LOT = intPreferencesKey("current_lot")
    val DATE = stringPreferencesKey("source_date")
    val CHECKED = stringPreferencesKey("checked_at")
    val STATUS = stringPreferencesKey("status")
}

class CheckLotWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val page = Jsoup.connect("https://portalextranjeria.com/lotes-nie-madrid/")
                .userAgent("Mozilla/5.0 (compatible; TIELoteWidget/1.0)")
                .timeout(20000).get()
            val text = page.text()
            val sanFelipeIndex = text.indexOf("Comisaría de Extranjería de San Felipe", ignoreCase = true)
            if (sanFelipeIndex < 0) return@withContext Result.retry()
            val relevant = text.substring(sanFelipeIndex, minOf(text.length, sanFelipeIndex + 1200))
            val lot = Regex("LOTE NIE MADRID ACTUAL:\\s*(\\d+)", RegexOption.IGNORE_CASE)
                .find(relevant)?.groupValues?.get(1)?.toIntOrNull() ?: return@withContext Result.retry()
            val date = Regex("Actualizado:\\s*(\\d{2}/\\d{2}/\\d{4})", RegexOption.IGNORE_CASE)
                .find(relevant)?.groupValues?.get(1) ?: "Fecha no indicada"
            val now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))
            val prefs = applicationContext.getSharedPreferences("tie_tracker", Context.MODE_PRIVATE)
            val target = prefs.getInt("target_lot", 297)
            val oldLot = prefs.getInt("last_lot", -1)
            val manager = GlanceAppWidgetManager(applicationContext)
            manager.getGlanceIds(TieLotWidget).forEach { id: GlanceId ->
                updateAppWidgetState(applicationContext, PreferencesGlanceStateDefinition, id) { state ->
                    state.toMutablePreferences().apply {
                        this[TrackerKeys.LOT] = lot
                        this[TrackerKeys.DATE] = date
                        this[TrackerKeys.CHECKED] = now
                        this[TrackerKeys.STATUS] = "ok"
                    }
                }
                TieLotWidget.update(applicationContext, id)
            }
            prefs.edit().putInt("last_lot", lot).putString("last_checked", now).apply()
            // Notify only on the first confirmed crossing of the target, not every day.
            val alreadyNotified = prefs.getBoolean("target_notified", false)
            if (lot >= target && !alreadyNotified) {
                notifyTargetReached(lot, target)
                prefs.edit().putBoolean("target_notified", true).apply()
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    private fun notifyTargetReached(lot: Int, target: Int) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel("tie_lote", "Seguimiento de lote TIE", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val notification = NotificationCompat.Builder(applicationContext, "tie_lote")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Comprueba tu TIE en San Felipe")
            .setContentText("La web publica el lote $lot y tu lote objetivo es $target. Verifica la recogida antes de desplazarte.")
            .setAutoCancel(true).build()
        manager.notify(297, notification)
    }
}
